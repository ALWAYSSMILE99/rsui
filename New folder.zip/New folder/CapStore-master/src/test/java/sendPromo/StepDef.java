package sendPromo;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class StepDef {

	@Given("^New products are added in product list$")
	public void new_products_are_added_in_product_list() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Send promotional email to customer$")
	public void send_promotional_email_to_customer() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^New offers are added in product list$")
	public void new_offers_are_added_in_product_list() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
